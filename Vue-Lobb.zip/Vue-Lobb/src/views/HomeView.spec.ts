import { mount } from '@vue/test-utils'
import HomeView from '@/views/HomeView.vue'
import { createTestingPinia } from '@pinia/testing'
import { describe, it, expect } from 'vitest'

function mountWithPinia() {
  return mount(HomeView, {
    global: {
      plugins: [createTestingPinia({ createSpy: () => () => {} })],
      stubs: {
        'el-button': {
          template: '<button class="el-button"><slot /></button>',
        },
        'el-card': {
          template: '<div class="el-card"><slot /><slot name="footer" /></div>',
        },
      },
    },
  })
}

describe('HomeView', () => {
  it('renders the date and today text', () => {
    const wrapper = mountWithPinia()
    expect(wrapper.text()).toContain('Today')
    expect(wrapper.find('.date-time').exists()).toBe(true)
  })

  it('renders the image card', () => {
    const wrapper = mountWithPinia()
    expect(wrapper.find('.image-card').exists()).toBe(true)
    expect(wrapper.find('.main-image').exists()).toBe(true)
  })

  it('refresh button exists', () => {
    const wrapper = mountWithPinia()
    // Find the Element Plus button by its class
    expect(wrapper.find('.el-button').exists()).toBe(true)
  })
})
