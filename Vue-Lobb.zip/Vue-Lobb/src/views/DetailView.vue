<template>
  <div class="detail-container">
    <!-- Title and Description -->
    <div class="title-section">
      <button class="close-button" @click="goBack">✖</button>
      <h2>
        <span class="fontBold">{{ currentData.name }}</span>
      </h2>
      <p class="description">{{ currentData.description }}</p>
    </div>

    <!-- Main Image Section -->
    <div class="detail-image-section">
      <el-card class="detail-image-card">
        <img :src="currentData.image" class="detail-image" alt="Detail" />
      </el-card>
    </div>

    <!-- Passages Section -->
    <div class="passages" v-if="currentData.passage?.length">
      <div v-for="(passage, index) in currentData.passage" :key="index">
        <h3>
          <span class="fontBold">{{ passage.heading }}</span>
        </h3>
        <p>{{ passage.text }}</p>
        <img :src="passage.image" class="passage-img" alt="Passage" />
      </div>
    </div>

    <!-- Footer Section -->
    <div class="custom-footer">
      <img :src="currentData.logo" alt="Footer Logo" class="footer-logo" />
      <div class="footer-text">
        <div class="footer-name">{{ currentData.name }}</div>
        <div class="footer-description">{{ currentData.description }}</div>
      </div>
      <div class="footer-button">
        <el-button round @click="refreshImage">Refresh</el-button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useImageStore } from '@/stores/useImageStore'

const route = useRoute()
const router = useRouter()
const store = useImageStore()

const currentData = ref({
  name: '',
  description: '',
  image: '',
  logo: '',
  passage: [],
})

const goBack = () => {
  router.back()
}

const refreshImage = () => {
  console.log('Refreshing image...')
}

onMounted(() => {
  const id = route.params.id as string

  if (id) {
    const data = store.imageData.find((item) => item._id === id)
    if (data) {
      currentData.value = JSON.parse(JSON.stringify(data))
    }
  }
  if (!currentData.value._id) {
    router.push('/')
  }
})
</script>

<style scoped>
.detail-container {
  max-width: 90%;
  margin: 0 auto;
  padding: 24px;
  min-height: 100vh;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

.detail-header {
  display: flex;
  justify-content: flex-end;
  position: sticky;
  top: 0;
  background: white;
  z-index: 10;
}
.close-button {
  position: absolute;
  top: 0;
  right: 0;
  font-size: 20px;
  border: none;
  background: none;
  color: #888;
  cursor: pointer;
  padding: 4px 8px;
  transition: color 0.3s ease;
}
.close-button:hover {
  color: #000;
}
.close-icon {
  font-size: 28px;
  cursor: pointer;
  color: #888;
}

.fontBold {
  font-weight: bold;
}

.detail-image-section {
  display: flex;
  justify-content: center;
  margin-bottom: 10px;
  width: 100%;
}

.detail-image-card {
  width: 100%;
  max-width: 500px;
  position: relative;
  padding: 0;
  border-radius: 5px;
  --el-card-padding: 0px;
}

.detail-image {
  width: 100%;
  height: auto;
  object-fit: cover;
  border-radius: 10px 10px 0 0;
  display: block;
  margin: 0 auto;
}
.close-icon:hover {
  color: #000;
}

.refresh-icon {
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 22px;
  color: #409eff;
  cursor: pointer;
  background: #fff;
  border-radius: 50%;
  padding: 4px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.title-section {
  position: relative;
  text-align: center;
  margin-bottom: 16px;
  padding: 0 32px;
  background-color: #f5f5f5;
}

.description {
  color: #555;
  margin-top: 8px;
  text-align: center;
}

.passages {
  width: 100%;
  font-size: 18px;
}

.passages h3 {
  margin-top: 18px;
  margin-bottom: 8px;
  text-align: center;
}

.passages p {
  text-align: justify;
  line-height: 1.6;
}

.passage-img {
  max-width: 800px;
  width: 100%;
  height: auto;
  margin: 12px auto;
  border-radius: 8px;
  display: block;
}

/* ✅ Footer Section Styling */
.custom-footer {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 32px;
  padding: 20px;
  background-color: #f5f5f5;
  border-top: 1px solid #e0e0e0;
}

.footer-logo {
  width: 64px;
  height: 64px;
  object-fit: cover;
  border-radius: 8px;
}

.footer-text {
  text-align: center;
  margin-top: 12px;
}

.footer-name {
  font-weight: bold;
  font-size: 18px;
}

.footer-description {
  font-size: 14px;
  color: gray;
  margin-top: 4px;
}

.footer-button {
  margin-top: 16px;
}

.upload-section {
  display: flex;
  justify-content: center;
  margin-top: 32px;
}
</style>

<style>
html,
body {
  height: 100%;
  margin: 0;
  padding: 0;
  overflow: hidden;
}

#app {
  height: 100%;
  overflow-y: auto;
}
</style>
