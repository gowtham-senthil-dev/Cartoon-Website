<template>
  <div class="main-container">
    <div class="content-box">
      <div class="date-time">{{ dateTime }}</div>
      <div class="logo-today">
        <div class="today-text">Today</div>
        <img
          class="logo"
          src="https://img.freepik.com/premium-vector/gk-letter-logo-design-black-background-gk-creative-initials-letter-logo-concept-gk-letter-design-gk-white-letter-design-black-background-g-k-g-k-logo_229120-136423.jpg"
          alt="Logo"
        />
      </div>

      <el-card class="image-card" shadow="hover">
        <img
          :src="store?.currentImage?.image"
          class="main-image"
          @click="goToDetail(store?.currentImage?._id)"
          alt="Random"
        />
        <template #footer>
          <div class="card-footer">
            <img class="footer-logo" :src="store?.currentImage?.logo" alt="Logo" />
            <div class="footer-text">
              <div class="name">{{ store?.currentImage?.name }}</div>
              <div class="description">{{ store?.currentImage?.description }}</div>
            </div>
            <el-button round @click="refreshImage">Refresh</el-button>
          </div>
        </template>
      </el-card>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useImageStore } from '@/stores/useImageStore'

const router = useRouter()
const store = useImageStore()
const dateTime = ref('')

const updateDateTime = () => {
  const now = new Date()
  const options: Intl.DateTimeFormatOptions = {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  }
  dateTime.value = now.toLocaleDateString('en-US', options)
}

onMounted(() => {
  store.fetchImages()
  updateDateTime()
})

const refreshImage = () => {
  store.toggleImage()
}

const goToDetail = (_id: string) => {
  router.push({ name: 'Detail', params: { id: _id } })
}
</script>

<style scoped>
.main-container {
  background: #f5f6fa;
  display: flex;
  justify-content: center;
  align-items: center;
  box-sizing: border-box;
}

.content-box {
  width: 100%;
  max-width: 450px;
  margin: auto;
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.date-time {
  font-size: 1.5rem;
  font-weight: bold;
  color: grey;
  margin-top: 6px;
}

.logo-today {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.logo {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  object-fit: cover;
}

.today-text {
  font-size: 1.8rem;
  font-weight: 600;
}

.image-card {
  width: 100%;
  max-width: 500px;
  position: relative;
  padding: 0;
  border-radius: 15px;
  --el-card-padding: 0px;
}

.main-image {
  width: 100%;
  height: auto;
  object-fit: cover;
  border-radius: 10px 10px 0 0;
  display: block;
  margin: 0 auto;
}

::v-deep(.el-card__footer) {
  margin: 0;
  padding: 16px;
  background: white;
}
.card-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1px;
  background: white;
  flex-wrap: wrap;
}

.footer-logo {
  width: 48px;
  height: 48px;
  border-radius: 5px;
  object-fit: cover;
}

.footer-text {
  flex: 1;
  display: flex;
  flex-direction: column;
  margin-left: 15px;
}

.footer-text .name {
  font-weight: bold;
  font-size: 1.1rem;
}

.footer-text .description {
  font-size: 0.9rem;
  color: gray;
}

.login-box {
  display: flex;
  flex-direction: column;
  gap: 10px;
  background: white;
  padding: 15px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

input[type='email'] {
  padding: 10px;
  font-size: 1rem;
  border: 1px solid #ddd;
  border-radius: 5px;
}

.error {
  color: red;
  font-size: 0.9rem;
  text-align: center;
  margin-top: 10px;
}

.loading-text {
  text-align: center;
  padding: 20px;
  font-size: 1.2rem;
  color: #666;
}
</style>

<style>
html,
body {
  height: 100%;
  width: 100%;
  margin: 0;
  padding: 0;
  overflow: hidden;
}
</style>
