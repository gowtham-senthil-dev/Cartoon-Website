import { setActivePinia, createPinia } from 'pinia'
import { useImageStore } from '@/stores/useImageStore'
import { describe, it, expect, beforeEach } from 'vitest'

describe('useImageStore', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
  })

  it('should initialize with the first image', () => {
    const store = useImageStore()
    expect(store.currentIndex).toBe(0)
    expect(store.currentImage).toBe(null)
  })

  it('should toggle to the next image', () => {
    const store = useImageStore()
    store.imageData = [{ name: 'A' }, { name: 'B' }, { name: 'C' }]
    store.currentIndex = 0
    store.toggleImage()
    expect(store.currentIndex).toBe(1)
    expect(store.currentImage).toBe(store.imageData[store.currentIndex])
  })

  it('should get image by name', () => {
    const store = useImageStore()
    store.imageData = [{ name: 'A' }, { name: 'B' }, { name: 'C' }]
    const name = store.imageData[1].name
    const found = store.getImageByName(name)
    expect(found).toBe(store.imageData[1])
  })
})
