import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import axios from 'axios'

export const useImageStore = defineStore('image', () => {
  const BASE_URL = 'http://localhost:4000'
  const USER_EMAIL = 'gowthamsenthil1708@gmail.com'

  const token = ref(localStorage.getItem('token'))
  const imageData = ref<any[]>([])
  const loading = ref(false)
  const error = ref<string | null>(null)
  const currentIndex = ref(0)

  const currentImage = computed(() => imageData.value[currentIndex.value] || null)

  // STEP 1: Ensure token
  const ensureToken = async () => {
    if (!token.value) {
      try {
        const res = await axios.post(`${BASE_URL}/auth/login`, { email: USER_EMAIL })
        token.value = res.data.token
        localStorage.setItem('token', token.value ?? '')
      } catch (err) {
        error.value = 'Failed to fetch token'
        token.value = null
        localStorage.removeItem('token')
        console.error(err)
      }
    }
  }

  // STEP 2: Fetch all images and store in imageData
  const fetchImages = async () => {
    loading.value = true
    error.value = null
    imageData.value = []

    await ensureToken()

    if (!token.value) {
      error.value = 'Token missing'
      loading.value = false
      return
    }

    try {
      const response = await axios.get(`${BASE_URL}/images`, {
        headers: {
          Authorization: `Bearer ${token.value}`,
        },
      })

      imageData.value = response.data
      currentIndex.value = 0 // reset current
    } catch (err: any) {
      if (err.response && err.response.status === 403) {
        // Expired or invalid token — remove it and retry
        console.warn('Token expired or invalid, removing and retrying...')
        localStorage.removeItem('token')
        token.value = null
        await fetchImages()
      } else {
        error.value = 'Failed to fetch images'
        console.error('Image fetch failed:', err)
      }
    } finally {
      loading.value = false
    }
  }

  // STEP 3: Navigation helpers
  const toggleImage = () => {
    if (imageData.value.length === 0) return
    currentIndex.value = (currentIndex.value + 1) % imageData.value.length
  }

  const getImageByName = (name: string) => {
    return imageData.value.find((item) => item.name === name)
  }

  return {
    imageData,
    loading,
    error,
    currentIndex,
    currentImage,
    fetchImages,
    ensureToken,
    toggleImage,
    getImageByName,
  }
})
