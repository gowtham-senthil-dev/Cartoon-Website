import express from 'express'
import cors from 'cors'
import jwt from 'jsonwebtoken'
import dotenv from 'dotenv'

dotenv.config()

const app = express()
const PORT = process.env.PORT || 4000
const JWT_SECRET = process.env.JWT_SECRET || 'supersecretkey'

app.use(cors())
app.use(express.json())

// Dummy random content generator
function getRandomImage() {
  const imageData = [
    {
      _id: '68562fc9d96da5197c0693a1',
      name: 'One Piece',
      description: 'Set sail for One Piece!',
      logo: 'https://img.freepik.com/free-vector/screaming-skull-pirate-illustration_43623-898.jpg?semt=ais_hybrid&w=740',
      image: 'https://i.pinimg.com/736x/dd/30/c9/dd30c9985cee898ce88e2c8d3b01399c.jpg',
      passage: [
        {
          heading: 'Follows the Adventures',
          text: `One Piece follows the epic journey of Monkey D. Luffy, a spirited and fearless boy who gains rubber-like abilities after eating the Gum-Gum Fruit, one of the mysterious Devil Fruits that grant supernatural powers. Inspired by his childhood hero, the Red-Haired Shanks, Luffy sets out from his small village to achieve the ultimate dream of becoming the Pirate King. But to do that, he must find the greatest treasure in the world—the fabled "One Piece," said to be hidden at the end of the Grand Line, a perilous sea route filled with chaos, legendary pirates, and powerful marine forces.
  
            Along his journey, Luffy builds an unforgettable crew known as the Straw Hat Pirates. Each member is unique, with their own dreams and reasons for joining Luffy. From Zoro, the master swordsman with unmatched loyalty, to Nami, the sharp and brave navigator; from Sanji, the chivalrous cook, to Usopp, the ever-evolving sniper, and beyond. Their camaraderie, combined strength, and shared vision of freedom define the essence of One Piece.
  
            The adventure takes them to imaginative islands like Skypiea, a floating sky kingdom; Water 7, a city of shipwrights; Enies Lobby, the site of a fierce battle for justice and friendship; and Wano, a land steeped in samurai legend. At every step, the Straw Hats face morally complex enemies, oppressive world governments, warlords, and celestial dragons. But through it all, Luffy’s will remains unshaken—he protects his friends and pushes forward, regardless of the danger.
  
            One Piece is more than a treasure hunt—it’s a story of inherited dreams, personal freedom, and unyielding friendship. The series blends action, humor, heartbreak, and hope into an unforgettable tale that has captivated readers and viewers for decades.`,
          image:
            'https://tiermaker.com/images/templates/one-piece-openings-1-24-1414129/14141291639978163.jpeg',
        },
        {
          heading: 'Wealth, Fame, Power',
          text: `Before his execution, the legendary pirate Gol D. Roger spoke his final words: "My treasure? If you want it, you can have it. Search for it! I left it all at that place!" With those words, he ignited the Great Pirate Era, sending people from all walks of life to the sea in search of the legendary treasure—One Piece. Roger was no ordinary pirate. He was the only one who had sailed across the Grand Line and discovered the world's hidden truths. His wealth, fame, and power were unmatched, making him the Pirate King.
  
            The idea of One Piece is shrouded in mystery—some believe it's material riches, others think it's something more profound. As the world rushes to claim it, the seas grow turbulent with rival pirate crews, bounty hunters, and the ever-watchful Marines. Amid this chaos, Luffy doesn't just seek treasure—he seeks freedom. Unlike many pirates who crave dominance, Luffy desires a life without constraint, where dreams have no limit and the journey itself is as valuable as the destination.
  
            The World Government, an organization that rules much of the known world, fears the secrets Gol D. Roger discovered. The Void Century, the Ancient Weapons, and the existence of the Will of D—these are truths buried deep in the seas, guarded by the world's strongest. But Roger, and later Luffy, dare to uncover them. In their own way, they represent hope for the oppressed and a threat to the corrupt status quo.
  
            The pursuit of wealth, fame, and power in One Piece is a metaphor for the pursuit of dreams. The most powerful characters are not those who conquer others, but those who conquer themselves and never give up on what they believe in. This timeless message resonates across cultures, making One Piece not just a pirate story, but a universal tale of ambition and courage.`,

          image:
            'https://w0.peakpx.com/wallpaper/530/838/HD-wallpaper-anime-portgas-d-ace-one-piece-tony-tony-chopper-usopp-one-piece-roronoa-zoro-monkey-d-luffy-nami-one-piece-sanji-one-piece-brook-one-piece-nico-robin-gekko-moriah-trafalgar-law-jewelry.jpg',
        },
        {
          heading: 'Inherited Will',
          image:
            'https://e0.pxfuel.com/wallpapers/542/436/desktop-wallpaper-the-whiteboard-pirates-barbe-blanche.jpg',

          text: `One of the most powerful themes in One Piece is the idea of “Inherited Will.” It speaks to the notion that dreams never die—they are passed on from one person to another, generation after generation. Luffy carries the will of his idol, Shanks, who once wore the very straw hat now resting on Luffy’s head. Shanks, in turn, received that hat from Gol D. Roger, the Pirate King himself. Through this lineage, Luffy becomes the symbol of inherited will, embodying the spirit of freedom and rebellion against oppression.
  
            Many characters in the One Piece world represent this theme. Ace, Luffy’s sworn brother and the son of Gol D. Roger, carries both the burden and pride of his lineage. His final stand at Marineford shows the world the price of carrying such a will. Nico Robin seeks to uncover the truth about the Void Century, continuing the mission of scholars from Ohara who were destroyed for their pursuit of knowledge. Even enemies such as Doflamingo and Law show how inherited will can take different forms—some noble, some twisted.
  
            This theme extends to the Will of D., a mysterious initial carried by many key figures. Though its full meaning is yet unknown, those who bear it seem fated to challenge the world's established order. Luffy, Blackbeard, Law—all hold the D. initial, and each plays a crucial role in the unfolding history of the world.
  
            As Luffy moves closer to the truth, he becomes more than a boy chasing treasure—he becomes the voice of the silenced, the hope of the forgotten, and the embodiment of a dream too powerful to be killed. His journey is not just his own—it belongs to every character who came before him and everyone who will follow. This is the heart of One Piece: that will, dreams, and freedom cannot be crushed. They will always rise again, in a new form, in a new person, in a new age.`,
        },
      ],
    },
    {
      _id: '68562ff4d96da5197c0693b4',
      name: 'Naruto',
      description: 'Dream the Hokage',
      logo: 'https://assets.turbologo.com/blog/en/2021/11/14061241/Konoha-symbol.png',
      image:
        'https://imgcdn.stablediffusionweb.com/2024/3/5/aede3c07-3e26-4e54-95f7-802913ff8283.jpg',
      passage: [
        {
          heading: 'The Lonely Boy Who Dared to Dream',
          image:
            'https://occ-0-8407-2433.1.nflxso.net/dnm/api/v6/Z-WHgqd_TeJxSuha8aZ5WpyLcX8/AAAABdIFYfkylotuQsosH1WlGXHoouJSR59IKXL-xHz1EBGnDra3h7PiJ0E7Oe8wZzKk0hpHSKQGHi7VrGSs64kozAD0u9dXXKO-T4SM.jpg?r=33e',
          text: `Naruto Uzumaki's story begins in the Hidden Leaf Village, a place filled with ancient ninja traditions and powerful warriors. From the moment he was born, Naruto was fated to be different. Sealed inside him was the Nine-Tailed Fox, a monstrous entity that had once ravaged the village, causing widespread destruction. As a result, the villagers viewed Naruto with fear and resentment, ostracizing him and leaving him to grow up alone, without family or friends. Despite this isolation, Naruto remained upbeat, determined to win the village’s approval and become its Hokage—the strongest ninja and its leader.
  
      What sets Naruto apart is not just the power sealed within him, but his unshakable will. He fails repeatedly in the ninja academy, and he’s mocked for his foolishness, but he never gives up. Every prank he pulls, every smile he forces is a plea for someone to acknowledge his existence. Over time, he begins to find friends who see beyond the demon fox—Iruka, his first mentor, who treats him like a real person; Sasuke, a rival who shares his pain; and Sakura, the teammate he admires. These relationships mark the beginning of Naruto's transformation from an outcast to a true hero.
  
      Naruto's journey is one of grit, heart, and persistence. He learns from failure, trains harder than anyone else, and confronts enemies much stronger than himself with nothing but guts and clever thinking. Each step he takes toward becoming Hokage is also a step toward healing the pain in his heart and changing the hearts of others. His story is a reminder that being acknowledged is a basic human need, and that dreams, no matter how impossible they seem, can come true with courage and determination.`,
        },
        {
          heading: 'Friendship, Rivalry, and Redemption',
          image: 'https://deadline.com/wp-content/uploads/2024/11/Naturo-_fc5c3e.jpg?w=1024',
          text: `One of the most powerful dynamics in Naruto is his relationship with Sasuke Uchiha. At first, Sasuke is a genius ninja—cool, distant, and admired by everyone—everything Naruto is not. Yet beneath that exterior is a boy consumed by the trauma of watching his clan be slaughtered by his own brother, Itachi. Naruto, who longs for acknowledgment, sees Sasuke both as a rival and as a brother. This bond pushes Naruto to train harder, but it also sets the stage for heartbreaking conflict.
  
      When Sasuke leaves the village to seek power from the enemy Orochimaru, Naruto refuses to give up on him. Their eventual battles are among the most intense and emotional in anime history. Naruto’s relentless pursuit to bring Sasuke back is not just about rivalry—it’s about the pain of losing someone he considers family. Sasuke, in turn, is torn between vengeance and the warmth of Naruto's unwavering friendship.
  
      Their final clash is not just a physical battle but a culmination of their conflicting ideologies. Naruto believes in forgiveness, bonds, and the possibility of change, while Sasuke clings to power and revenge. It is through Naruto’s persistence and willingness to die for his friend that Sasuke is finally redeemed. This arc showcases the deep emotional layers in Naruto—how strength isn’t just physical but also emotional and moral. It’s a story of broken people learning to love, trust, and heal, proving that even the deepest wounds can be mended through empathy and determination.`,
        },
        {
          heading: 'From Orphan to Hokage',
          image: 'https://i.ytimg.com/vi/4ooE1Sw0ino/maxresdefault.jpg',
          text: `Naruto’s ultimate goal has always been to become Hokage—the leader of the Hidden Leaf Village. But his path is anything but easy. He faces threats from within and outside the village: rogue ninja, monstrous enemies like the Akatsuki, and internal battles with the Nine-Tails sealed within him. Despite it all, Naruto stays true to his beliefs. He values friendship, unity, and never giving up, and he’s always willing to sacrifice himself to protect others.
  
      Throughout the series, Naruto matures from a loud, unpredictable child into a wise, compassionate leader. His mastery of powerful techniques like Rasengan, Sage Mode, and eventually harnessing the power of the Nine-Tails, is a testament to his growth. But more than jutsu, it is Naruto's heart that makes him worthy of the title. He reaches out to his enemies, believing that they, too, can change. He inspires others—not just in his village, but across the entire ninja world.
  
      The culmination of his journey is seen when he finally becomes the Seventh Hokage. It is a moment filled with emotion, not just for Naruto, but for everyone who watched him grow. He now stands as a protector, a father, a husband, and a symbol of hope. The boy who once had nothing now has everything he dreamed of—not because of luck or power alone, but because he never stopped believing. Naruto’s journey is not just a story of battles—it’s a story of believing in oneself and never giving up, no matter how hard the road.`,
        },
      ],
    },
  ]

  return imageData
}

// Auth endpoint
app.post('/auth/login', (req, res) => {
  const { email } = req.body
  if (!email || !email.includes('@')) {
    return res.status(400).json({ error: 'Valid email required' })
  }
  const token = jwt.sign({ email }, JWT_SECRET, { expiresIn: '1h' })
  res.json({ token })
})

// Middleware to check token
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization']
  const token = authHeader && authHeader.split(' ')[1]
  if (!token) return res.status(401).json({ error: 'Token required' })
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Invalid token' })
    req.user = user
    next()
  })
}

// Protected random content endpoint
app.get('/images', authenticateToken, (req, res) => {
  const images = getRandomImage()
  res.json(images)
})

app.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`)
})
